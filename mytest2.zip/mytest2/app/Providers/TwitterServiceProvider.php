<?php

// /project-folder/app/Providers/TwitterServiceProvider.php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Atymic\Twitter\Contract\Twitter as TwitterContract;
use Atymic\Twitter\Twitter;

class TwitterServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton(TwitterContract::class, function () {
            return new Twitter([
                'consumer_key'        => config('services.twitter.consumer_key'),
                'consumer_secret'     => config('services.twitter.consumer_secret'),
                'access_token'        => config('services.twitter.access_token'),
                'access_token_secret' => config('services.twitter.access_token_secret'),
            ]);
        });
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
