<?php
//Mytest/app/Api/V1/Controllers/ChatController.php

namespace App\Api\V1\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Atymic\Twitter\Contract\Twitter;

class ChatController extends Controller
{

    protected $twitter;

    public function __construct(Twitter $twitter)
    {
        $this->twitter = $twitter;
    }

    /**
     * Subscribe users to a chat bot.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\JsonResponse
     *
     * @SWG\Post(
     *     path="/subscribe",
     *     summary="Subscribe users to a chat bot",
     *     tags={"Chat"},
     *     consumes={"application/json"},
     *     produces={"application/json"},
     *     @SWG\Response(
     *         response=200,
     *         description="Successfully subscribed to a chat bot",
     *         @SWG\Schema(
     *             type="object",
     *             @SWG\Property(property="message", type="string", example="Subscribed successfully"),
     *         )
     *     ),
     * )
     */
    public function subscribe(Request $request)
    {
        // Access User ID from the request header
        $userID = $request->header('User-ID');

        // Check if the user exists in the database
        $user = User::where('user_id', $userID)->first();

        if (!$user) {
            return response()->json(['error' => 'User not found'], 404);
        }

        // Subscribe logic with Twitter SDK
        $this->twitter->post('subscribe-endpoint', ['user_id' => $user->user_id]);

        return response()->json(['message' => 'Subscribed successfully']);
    }

    /**
     * Subscribe users to a channel or chat.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\JsonResponse
     *
     * @SWG\Post(
     *     path="/subscribe/channel",
     *     summary="Subscribe users to a channel or chat",
     *     tags={"Chat"},
     *     consumes={"application/json"},
     *     produces={"application/json"},
     *     @SWG\Response(
     *         response=200,
     *         description="Successfully subscribed to a channel or chat",
     *         @SWG\Schema(
     *             type="object",
     *             @SWG\Property(property="message", type="string", example="Subscribed to channel successfully"),
     *         )
     *     ),
     * )
     */
    public function subscribeToChannel(Request $request)
    {
        // Your logic for subscribing to a channel or chat
        // Access User ID from the request header
        $userID = $request->header('User-ID');

        // Check if the user exists in the database
        $user = User::where('user_id', $userID)->first();

        if (!$user) {
            return response()->json(['error' => 'User not found'], 404);
        }

        // Subscribe logic with Twitter SDK for channels
        $this->twitter->post('subscribe-channel-endpoint', ['user_id' => $user->user_id]);

        return response()->json(['message' => 'Subscribed to channel successfully']);
    }

    /**
     * Send messages to subscribers.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\JsonResponse
     *
     * @SWG\Post(
     *     path="/send-message",
     *     summary="Send messages to subscribers",
     *     tags={"Chat"},
     *     consumes={"application/json"},
     *     produces={"application/json"},
     *     @SWG\Response(
     *         response=200,
     *         description="Message sent successfully",
     *         @SWG\Schema(
     *             type="object",
     *             @SWG\Property(property="message", type="string", example="Message sent successfully"),
     *         )
     *     ),
     * )
     */
    public function sendMessage(Request $request)
    {
        // Your logic for sending messages to subscribers
        // Access User ID from the request header
        $userID = $request->header('User-ID');

        // Check if the user exists in the database
        $user = User::where('user_id', $userID)->first();

        if (!$user) {
            return response()->json(['error' => 'User not found'], 404);
        }

        // Send message logic with Twitter SDK
        $this->twitter->post('send-message-endpoint', ['user_id' => $user->user_id, 'message' => $request->input('message')]);

        return response()->json(['message' => 'Message sent successfully']);
    }

    /**
     * Webhooks to receive responses from the messenger API.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\JsonResponse
     *
     * @SWG\Post(
     *     path="/webhook",
     *     summary="Webhooks to receive responses from the messenger API",
     *     tags={"Chat"},
     *     consumes={"application/json"},
     *     produces={"application/json"},
     *     @SWG\Response(
     *         response=200,
     *         description="Webhook received successfully",
     *         @SWG\Schema(
     *             type="object",
     *             @SWG\Property(property="message", type="string", example="Webhook received successfully"),
     *         )
     *     ),
     * )
     */
    public function webhook(Request $request)
    {
        // Your logic for handling webhooks
        $payload = $request->all();

        // Process the payload, for example, log it or perform some action
        // You may also want to validate the payload against a secret or perform other checks

        // Sample: Log the payload
        \Log::info('Webhook received:', $payload);

        return response()->json(['message' => 'Webhook received successfully']);
    }
}
