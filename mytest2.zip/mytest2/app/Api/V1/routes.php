<?php

// /project-folder/app/Api/V1/routes.php
$router->get('/test', function () {
    return response()->json(['message' => 'Test route working']);
});
$router->group(['prefix' => 'api/v1', 'namespace' => 'App\Api\V1\Controllers'], function ($router) {
    // Subscribe users to a chat bot
    $router->post('/subscribe', 'ChatController@subscribe');

    // Subscribe users to a channel or chat
    $router->post('/subscribe/channel', 'ChatController@subscribeToChannel');

    // Send messages to subscribers
    $router->post('/send-message', 'ChatController@sendMessage');

    // Webhooks to receive responses from the messenger API
    $router->post('/webhook', 'ChatController@webhook');
});
